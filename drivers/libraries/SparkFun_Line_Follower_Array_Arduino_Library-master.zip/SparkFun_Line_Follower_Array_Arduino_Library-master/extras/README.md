Any extra documentation that should accompany the library.

This directory is ignored by the Arduino Package manager, so do not place vital files in here! 